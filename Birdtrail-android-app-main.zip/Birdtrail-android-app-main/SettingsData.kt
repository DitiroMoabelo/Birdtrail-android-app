package com.example.birdtrail

data class SettingsData
    (val distanceValue: String, val distanceUnit: String) //(Jansen Van Rensburg, 2024)


